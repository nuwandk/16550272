﻿using Cpif.Cloud.Common.Utility;
using Cpif.Cloud.Common.DataContract;
using Cpif.Framework.Mef.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Receiver.Azure.Plugin
{
    [Export(typeof(IOperation))]
    [ExportMetadata("Command", "AzureCloudReceiveProcessor")]
    public class AzureCloudReceiveProcessor : IOperation
    {
        public string Operate(bool IsQueue)
        {
            AzureCloudQueueReceiverEngine receiver = new AzureCloudQueueReceiverEngine();
            // Data Received from the Queue
            receiver.ReceiveMessage(true);

            return "Successfully received the message";
        }
    }
}


