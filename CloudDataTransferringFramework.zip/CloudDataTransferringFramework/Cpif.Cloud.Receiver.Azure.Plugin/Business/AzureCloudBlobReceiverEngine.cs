﻿using Cpif.Cloud.Common.Utility;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.IO;

namespace Cpif.Cloud.Receiver.Azure.Plugin
{
    public class AzureCloudBlobReceiverEngine
    {
        #region Constants

        /// <summary>
        /// Represents temporary file post fix
        /// </summary>
        private const string TempFileSuffix = "_temp";
        internal const string DeleteBlob = "DeleteBlobAfterDownalod";
        internal const string BufferSize = "BufferSize";
        internal const string BlobConnectionString = "Microsoft.Storage.ConnectionString";
        internal const string BlobContainerName = "ContainerName";
        #endregion

        private bool deleteBlobAfterDownload;
        private string storageConnectionString;
        private string containerName;
        private int bufferSize;

        /// <summary>
        /// Initializes a new instance of the <see cref="AzureCloudBlobReceiverEngine"/> class.
        /// </summary>
        public AzureCloudBlobReceiverEngine()
        {
            deleteBlobAfterDownload = Convert.ToBoolean(CloudConfigurationManager.GetSetting(DeleteBlob));
            storageConnectionString = CloudConfigurationManager.GetSetting(BlobConnectionString);
            containerName = CloudConfigurationManager.GetSetting(BlobContainerName);
            bufferSize = Convert.ToInt32(CloudConfigurationManager.GetSetting(BufferSize)) * 1024;

        }

        /// <summary>
        /// Downloads the BLOB data.
        /// </summary>
        /// <param name="blobName">Name of the BLOB.</param>
        /// <param name="originalFileName">Name of the original file.</param>
        /// <param name="clientDownloadFolderPath">The client download folder path.</param>
        /// <exception cref="System.ArgumentNullException">Container is not exist</exception>
        public void DownloadBlobData(string blobName, string originalFileName, string clientDownloadFolderPath)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);
            string filePath = Path.Combine(clientDownloadFolderPath, originalFileName);

            if (!container.Exists())
            {
                throw new ArgumentNullException("Container is not exist");
            }

            if (!Directory.Exists(clientDownloadFolderPath))
            {
                Directory.CreateDirectory(clientDownloadFolderPath);
            }

            long payloadLength = GetBlobLength(container, blobName);

            if (payloadLength == 0)
            {
                Utility.CreateEmptyFile(filePath);
                DeleteFileFromContainer(container, blobName);
            }
            else
            {
                DownloadPayloadBlob(container, clientDownloadFolderPath, originalFileName, blobName, payloadLength);
            }
        }

        /// <summary>
        /// Downloads the payload BLOB.
        /// </summary>
        /// <param name="container">The container.</param>
        /// <param name="clientDownloadFolderPath">The client download folder path.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="blobName">Name of the BLOB.</param>
        /// <param name="payloadLength">Length of the payload.</param>
        public void DownloadPayloadBlob(CloudBlobContainer container, string clientDownloadFolderPath, string fileName, string blobName, long payloadLength)
        {
            byte[] payloadData = new byte[payloadLength];
            long pathSize = 0;
            long startPos = 0;
            bool isAvailable = false;

            try
            {
                string tempFileName = string.Concat(fileName, TempFileSuffix);
                string downloadTempFolderPath = Path.Combine(clientDownloadFolderPath, tempFileName);
                string downloadOriginalFolderPath = Path.Combine(clientDownloadFolderPath, fileName);

                if (File.Exists(downloadTempFolderPath))
                {
                    using (var stream = new FileStream(downloadTempFolderPath, FileMode.Open))
                    {
                        pathSize = payloadLength - stream.Length;
                        startPos = stream.Length;
                        isAvailable = true;
                    }
                }
                else
                {
                    pathSize = payloadLength;
                    isAvailable = false;
                }

                CloudBlockBlob payloadBlockBlob = container.GetBlockBlobReference(blobName);
                DownloadBlob(payloadBlockBlob, downloadTempFolderPath, downloadOriginalFolderPath,
                    pathSize, payloadData, startPos, isAvailable);
            }
            catch
            {
                throw;
            }
        }

        public void DownloadBlob(CloudBlockBlob blob, string downloadTempFolderPath, string downloadOriginalFolderPath, long blobLengthRm, byte[] inbytes, long startPosition, bool isAvailable)
        {
            string saveDataLogMessage = string.Empty;

            try
            {
                double downloadingSize = 0;
                do
                {
                    long blockSize = Math.Min(bufferSize, blobLengthRm);
                    byte[] blobContents = new byte[blockSize];
                    
                    using (MemoryStream ms = new MemoryStream())
                    {
                        blob.DownloadRangeToStream(ms, startPosition, blockSize);
                        ms.Position = 0;

                        ms.Read(blobContents, 0, blobContents.Length);

                        // When temp file available append the rest of the byte stream.
                        if (isAvailable == true)
                        {
                            using (FileStream fs = new FileStream(downloadTempFolderPath, FileMode.Append, FileAccess.Write))
                            {
                                fs.Position = startPosition;
                                fs.Write(blobContents, 0, blobContents.Length);
                            }
                        }
                        else
                        {
                            using (FileStream fs = new FileStream(downloadTempFolderPath, FileMode.OpenOrCreate))
                            {
                                fs.Position = startPosition;
                                fs.Write(blobContents, 0, blobContents.Length);
                            }
                        }

                        downloadingSize = blockSize / 1024;
                    }

                    startPosition += blockSize;
                    blobLengthRm -= blockSize;
                }
                while (blobLengthRm > 0);

                string s3FileName = Path.GetFileName(downloadOriginalFolderPath);
                string fileSizeMsg = string.Concat(downloadingSize.ToString(), " KB");

                if (deleteBlobAfterDownload)
                {
                    // Delete the blob after download
                    blob.DeleteIfExists();
                }

                Utility.RemoveOldFile(downloadOriginalFolderPath);

                // When completes the download rename temp file name to original file name
                File.Move(downloadTempFolderPath, downloadOriginalFolderPath);
                saveDataLogMessage = "Successfully Received Data From Blob:- " + s3FileName + " | Size:- " + fileSizeMsg;
                LogDataFacade.LogInfo(saveDataLogMessage);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Gets the length of the BLOB.
        /// </summary>
        /// <param name="blobContainer">The BLOB container.</param>
        /// <param name="blobName">Name of the BLOB.</param>
        /// <returns>System.Int64.</returns>
        public long GetBlobLength(CloudBlobContainer blobContainer, string blobName)
        {
            CloudBlockBlob payloadBlockBlob = blobContainer.GetBlockBlobReference(blobName);
            payloadBlockBlob.FetchAttributes();

            try
            {
                var blobLength = payloadBlockBlob.Properties.Length;
            }
            catch (Exception)
            {
                throw;
            }

            return payloadBlockBlob.Properties.Length;
        }


        /// <summary>
        /// Deletes the file from container.
        /// </summary>
        /// <param name="container">The container.</param>
        /// <param name="fileName">Name of the file.</param>
        private void DeleteFileFromContainer(CloudBlobContainer container, string fileName)
        {
            CloudBlockBlob payloadBlockBlob = container.GetBlockBlobReference(fileName);
            payloadBlockBlob.DeleteIfExists();
        }

    }
}
