﻿using Cpif.Cloud.Common.Utility;
using Cpif.Cloud.Common.DataContract;
using Cpif.Cloud.Receiver.Azure.Plugin.Contracts;
using Microsoft.Azure;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Cpif.Cloud.Receiver.Azure.Plugin
{
    public class AzureCloudQueueReceiverEngine : IReceiver
    {
        #region Config Keys

        internal const string IsArchiveData = "IsDataRecording";
        internal const string IsArchiveLocation = "DataRecordingLocation";
        internal const string ThreadCount = "ReceiverThreadCount";
        internal const string ServiceBusQueue = "SbQueueName";
        internal const string ConnectionString = "Microsoft.ServiceBus.ConnectionString";
        internal const string DownloadFolderPath = "DownloadFolderPath";
        #endregion

        #region Constants

        private const string SessionId = "Session";
        private const string MetaDataFlag = "1";
        private const string PayloadFlag = "2";
        private const string DataLocation = "DataLocation";
        private const string RecordPrefix = "Received";

        #endregion

        #region Private Properties

        private string serviceBusConnectionString;
        private string serviceBusQueueName;
        private string serviceBusSubscriptionName;
        private string serviceBusTopicName;
        private int threadCount;
        private bool isDataRecording;
        private string dataRecordingLocation;

        #endregion 

        #region Constructor

        public AzureCloudQueueReceiverEngine()
        {
            // Retrive the data recording status
            this.isDataRecording = Convert.ToBoolean(CloudConfigurationManager.GetSetting(IsArchiveData));
            // Retrive the data recording location
            this.dataRecordingLocation = CloudConfigurationManager.GetSetting(IsArchiveLocation);
        }

        #endregion

        #region Public Methods

        public void ReceiveMessage(bool isQueueClient)
        {
            serviceBusConnectionString = CloudConfigurationManager.GetSetting(ConnectionString);
            serviceBusQueueName = CloudConfigurationManager.GetSetting(ServiceBusQueue);
            NamespaceManager namespaceManager = NamespaceManager.CreateFromConnectionString(serviceBusConnectionString);
            threadCount = Convert.ToInt32(CloudConfigurationManager.GetSetting(ThreadCount));

            if (isQueueClient)
            {
                // Check service bus topic exist in the namespace
                if (!namespaceManager.QueueExists(serviceBusQueueName))
                {
                    LogDataFacade.LogErrors("Azure Queue is not exist");
                    return;
                }

                // Call the receiver
                ReceiveQueueData();
                while (true)
                {
                    Thread.Sleep(500);
                }
            }
            else
            {
                LogDataFacade.LogErrors("isQueueClient is set to false");
            }
        }

        #endregion

        #region Private Methods


        /// <summary>
        /// Receives the queue data.
        /// </summary>
        private void ReceiveQueueData()
        {
            // Create a MessagingFactory to send and receive messages
            MessagingFactory messagingFactory = MessagingFactory.CreateFromConnectionString(serviceBusConnectionString);
            // Create the queue client to accept the session enable messages.
            QueueClient queueClient = messagingFactory.CreateQueueClient(serviceBusQueueName);

            try
            {
                OnMessageOptions options = new OnMessageOptions();
                // Indicates if the message-pump should call complete on messages after the callback has completed processing.
                options.AutoComplete = false;
                // Indicates the maximum number of concurrent calls to the callback the pump should initiate 
                options.MaxConcurrentCalls = threadCount;
                // Allows users to get notified of any errors encountered by the message pump.
                options.ExceptionReceived += LogErrors;
                options.AutoRenewTimeout = TimeSpan.FromSeconds(30);

                List<CpifCloudMessage> metaDataList = new List<CpifCloudMessage>();

                // Initiates the message pump and callback is invoked for each message that is recieved, calling close on the client will stop the pump.
                queueClient.OnMessage((receivedMessage) =>
                {
                    try
                    {
                        string dataLocation = receivedMessage.Properties[DataLocation].ToString();
                        string sessionId = receivedMessage.Properties[SessionId].ToString();
                        string messageId = receivedMessage.MessageId;
                        string downloadFolderPath = CloudConfigurationManager.GetSetting(DownloadFolderPath);

                        CpifCloudMessage cloudMessage;

                        if (dataLocation.Equals(StreamLocation.InMessage.ToString()))
                        {
                            if (messageId == MetaDataFlag)
                            {
                                // Get the brokerd message boday stream
                                Stream metadataMessageStream = receivedMessage.GetBody<Stream>();
                                cloudMessage = (CpifCloudMessage)FileDataUtility.DeserializeDataStream(metadataMessageStream);
                                metaDataList.Add(cloudMessage);
                                receivedMessage.Complete();
                            }
                            else
                            {
                                CpifCloudMessage metaDataMessage = metaDataList.Find(e => e.SessionDataId.Equals(sessionId));

                                if (metaDataMessage != null)
                                {
                                    Stream dataStream = receivedMessage.GetBody<Stream>();
                                    string originalFileName = metaDataMessage.MessageDataProperties.Find
                                    (e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;
                                    string fullFilePath = Path.Combine(downloadFolderPath, originalFileName);
                                    // Write Data to disk
                                    Utility.WriteDataToDisk(fullFilePath, dataStream);
                                    // Remove the metadata message from the list
                                    metaDataList.Remove(metaDataMessage);
                                    receivedMessage.Complete();

                                    LogDataFacade.LogInfo(string.Concat("Successfuly Receive The Data From Queue : ", originalFileName));
                                }
                                else
                                {
                                    receivedMessage.Abandon();
                                }
                            }
                        }
                        else
                        {
                            // Get the brokerd message boday stream
                            Stream metadataMessageStream = receivedMessage.GetBody<Stream>();
                            cloudMessage = (CpifCloudMessage)FileDataUtility.DeserializeDataStream(metadataMessageStream);
                            string blobName = sessionId;
                            string originalFileName = cloudMessage.MessageDataProperties.Find
                                (e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;

                            // Receive the blob related data
                            new AzureCloudBlobReceiverEngine().DownloadBlobData(blobName, originalFileName, downloadFolderPath);
                            receivedMessage.Complete();
                            //LogDataFacade.LogInfo(string.Concat("Successfuly Received Data From Queue : ", originalFileName));
                            FileDataUtility.ArchiveData(isDataRecording, dataRecordingLocation, originalFileName, RecordPrefix);
                        }
                    }
                    catch (Exception ex)
                    {
                        receivedMessage.Abandon();
                        LogDataFacade.LogErrors("Data Download Error :" + ex.Message);
                    }
                }, options);
            }
            catch (Exception ex)
            {
                LogDataFacade.LogErrors("Error :" + ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Logs the errors.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="ExceptionReceivedEventArgs"/> instance containing the event data.</param>
        private void LogErrors(object sender, ExceptionReceivedEventArgs e)
        {
            if (e.Exception != null)
            {
                LogDataFacade.LogErrors("Error Received: " + e.Exception.Message);
            }
        }

        #endregion
    }
}
