﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Receiver.Azure.Plugin
{
    public static class Utility
    {

        /// <summary>
        /// Create a zero byte file
        /// </summary>
        /// <param name="filename"></param>
        public static void CreateEmptyFile(string filePath)
        {
            RemoveOldFile(filePath);
            File.Create(filePath).Dispose();
        }

        /// <summary>
        /// This method will write the data to disk 
        /// </summary>
        /// <param name="downloadFolderPath"></param>
        /// <param name="cdtfStreamData"></param>
        public static void WriteDataToDisk(string fullFilePath, Stream cdtfStreamData)
        {
            FileInfo file = new FileInfo(fullFilePath);
            if (!Directory.Exists(file.Directory.FullName))
                file.Directory.Create();

            RemoveOldFile(fullFilePath);

            using (FileStream fs = new FileStream(fullFilePath, FileMode.OpenOrCreate))
            {
                byte[] bytesInStream = new byte[cdtfStreamData.Length];
                cdtfStreamData.Read(bytesInStream, 0, bytesInStream.Length);
                // Use write method to write to the file specified above
                fs.Write(bytesInStream, 0, bytesInStream.Length);
            }
        }


        /// <summary>
        /// This method remove the old files
        /// </summary>
        /// <param name="fullFilePath"></param>
        public static void RemoveOldFile(string fullFilePath)
        {
            FileInfo filInfo = new FileInfo(fullFilePath);

            if (filInfo.Exists)
            {
                filInfo.Delete();
            }
        }



        /// <summary>
        /// This method round up the divide
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public static long DivideRoundingUp(long x, long y)
        {
            long remainder;
            long quotient = Math.DivRem(x, y, out remainder);
            return remainder == 0 ? quotient : quotient + 1;
        }
    }
}
