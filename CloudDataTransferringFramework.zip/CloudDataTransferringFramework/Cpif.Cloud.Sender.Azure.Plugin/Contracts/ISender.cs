﻿using Cpif.Cloud.Common.DataContract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Sender.Azure.Plugin.Contracts
{
    public interface ISender
    {
        void SendData(CpifCloudMessage cloudMessage, bool isQueueClient);
    }
}
