﻿using Cpif.Cloud.Common.Utility;
using Cpif.Cloud.Common.DataContract;
using Cpif.Framework.Mef.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Cpif.Cloud.Sender.Azure.Plugin
{
    [Export(typeof(IOperation))]
    [ExportMetadata("Command", "AzureCloudSendProcessor")]
    public class AzureCloudSendProcessor : IOperation
    {
        private const string SendFolder = "FolderLocation";
        private static List<string> messagesList = new List<string>();
        private static List<string> pickedMessageList = new List<string>();
        private static string ip = LocalIPAddress;
        private static string originalLocation = "Sender Side";
        private static string senderName = "Azure Cloud Sender";

        public string Operate(bool IsQueue)
        {
            while (true)
            {
                try
                {
                    string folderLocation = ConfigurationManager.AppSettings[SendFolder].ToString();
                    messagesList = FileDataUtility.GetFilesFromFolder(folderLocation);
                    string payloadPath = FileDataUtility.GetDataFiles(folderLocation, ref messagesList, ref pickedMessageList);
                    try
                    {
                        if (!String.IsNullOrEmpty(payloadPath))
                        {
                            CpifCloudMessage message = FileDataUtility.CreateCloudDataMessage(payloadPath, originalLocation, senderName);
                            AzureCloudSenderEngine dataSender = new AzureCloudSenderEngine();
                            // Data Send to Queue
                            dataSender.SendData(message, true);

                            //Force clean up
                            GC.Collect();
                            pickedMessageList.Remove(payloadPath);
                            FileDataUtility.DeleteDeliveredFile(payloadPath);
                        }
                    }
                    catch (Exception ex)
                    {
                        LogDataFacade.LogErrors("Error Occurred in picked file:- " + ex.Message, ex.StackTrace);
                        pickedMessageList.Remove(payloadPath);
                        FileDataUtility.DeleteDeliveredFile(payloadPath);
                    }
                }
                catch (Exception ex)
                {
                    LogDataFacade.LogErrors("Error Occurred:- " + ex.Message, ex.StackTrace);

                }
                Thread.Sleep(200);
            }
        }

        public static string LocalIPAddress
        {
            get
            {
                var host = Dns.GetHostEntry(Dns.GetHostName());
                foreach (var ip in host.AddressList)
                {
                    if (ip.AddressFamily == AddressFamily.InterNetwork)
                    {
                        return ip.ToString();
                    }
                }
                throw new Exception("No network adapters with an IPv4 address in the system!");
            }
        }
    }
}
