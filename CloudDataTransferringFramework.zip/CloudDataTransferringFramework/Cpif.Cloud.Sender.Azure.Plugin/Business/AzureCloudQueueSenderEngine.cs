﻿using Cpif.Cloud.Common.DataContract;
using Cpif.Cloud.Common.Utility;
using Cpif.Cloud.Sender.Azure.Plugin.Contracts;
using Microsoft.Azure;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using System;
using System.IO;
using System.Threading;

namespace Cpif.Cloud.Sender.Azure.Plugin
{
    public class AzureCloudSenderEngine : ISender
    {
        #region Config Keys

        private const string IsDataArchive = "IsDataRecording";
        private const string ArchiveLocation = "DataRecordingLocation";
        private const string DataLocation = "DataLocation";
        private const string ServiceBusQueueName = "SbQueueName";
        private const string ServiceBusConnection = "Microsoft.ServiceBus.ConnectionString";
        private const string MessageBodySize = "MessageBodySizeInKB";
        private const string ServiceBusTopicName = "SbTopicName";

        #endregion

        #region Constants

        private const string SessionId = "Session";
        private const string SubscriptionFilter = "SubscriptionFilter";
        private const string RecordPrefix = "Transfered";
        private const string MetaDataFlag = "1";
        private const string PayloadFlag = "2";
        #endregion

        #region Private Properties

        private dynamic client;
        private bool isDataRecording;
        private string dataRecordingLocation;
        private string serviceBusConnectionString;
        private string serviceBusTopicName;
        private string serviceBusQueueName;
        private string subscriptionFilter;

        #endregion

        #region Constructor

        public AzureCloudSenderEngine()
        {
            this.isDataRecording = Convert.ToBoolean(CloudConfigurationManager.GetSetting(IsDataArchive));
            this.dataRecordingLocation = CloudConfigurationManager.GetSetting(ArchiveLocation);
            this.serviceBusConnectionString = CloudConfigurationManager.GetSetting(ServiceBusConnection);
            this.serviceBusTopicName = CloudConfigurationManager.GetSetting(ServiceBusTopicName);
            this.serviceBusQueueName = CloudConfigurationManager.GetSetting(ServiceBusQueueName);
            this.subscriptionFilter = CloudConfigurationManager.GetSetting(SubscriptionFilter);
        }
        #endregion

        #region Public Method

        /// <summary>
        /// Sends the data.
        /// </summary>
        /// <param name="cloudMessage">The cloud message.</param>
        /// <param name="isQueueClient">if set to <c>true</c> [is queue client].</param>
        public void SendData(CpifCloudMessage cloudMessage, bool isQueueClient)
        {
            NamespaceManager namespaceManager = NamespaceManager.CreateFromConnectionString(serviceBusConnectionString);
            // Create a unique message Id.
            string sessionId = Guid.NewGuid().ToString();

            if (isQueueClient)
            {
                // Check service bus topic exist in the namespace
                if (!namespaceManager.QueueExists(serviceBusQueueName))
                {
                    LogDataFacade.LogErrors("Warning : Queue is not exist");
                    return;
                }

                // Create the topic client to send messages
                client = QueueClient.CreateFromConnectionString(serviceBusConnectionString, serviceBusQueueName);
            }
            else
            {
                // Check service bus topic exist in the namespace
                if (!namespaceManager.TopicExists(serviceBusTopicName))
                {
                    LogDataFacade.LogErrors("Warning : Topic is not exist");
                    return;
                }

                // Create the topic client to send messages
                client = TopicClient.CreateFromConnectionString(serviceBusConnectionString, serviceBusTopicName);
            }

            // Get the message body size in config and convert it to bytes
            int messageBodySize =
                Int32.Parse(
                CloudConfigurationManager.GetSetting(MessageBodySize)) * 1024;

            if (cloudMessage.ActualData.Length <= messageBodySize)
            {
                try
                {
                    string fileName = cloudMessage.MessageDataProperties.Find(e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;
                    cloudMessage.SessionDataId = sessionId;

                    // Convert RdmMessage payload to file stream
                    FileStream cloudPayloadStreamData = (FileStream)cloudMessage.ActualData;
                    cloudMessage.ActualData = new MemoryStream();

                    // Convert CloudMessage to memory stream
                    MemoryStream cloudMetaDataStreamMessage = FileDataUtility.SerializeToStream(cloudMessage);
                    cloudMetaDataStreamMessage.Position = 0;

                    //Send the cloud meta data message as stream 
                    SendToQueue(client, cloudMetaDataStreamMessage,
                        subscriptionFilter, cloudMessage.DeliveryAddress, MetaDataFlag, sessionId, StreamLocation.InMessage.ToString());

                    //Send the cloud data as stream 
                    SendToQueue(client, cloudPayloadStreamData,
                        subscriptionFilter, cloudMessage.DeliveryAddress, PayloadFlag, sessionId, StreamLocation.InMessage.ToString());

                    //LogDataFacade.LogInfo(cloudMessage);
                    string filename = cloudMessage.MessageDataProperties.Find(e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;
                    string logMessage = "Message Successfully sent to the Azure Queue:- " + filename;
                    LogDataFacade.LogInfo(logMessage);

                }
                catch (Exception ex)
                {
                    LogDataFacade.LogErrors(ex.Message);
                }
            }
            else
            {
                try
                {
                    // Seperate the payload from the CloudMessage
                    Stream dataStream = cloudMessage.ActualData;
                    cloudMessage.ActualData = new MemoryStream();

                    // Set the file name as the target name
                    sessionId = cloudMessage.MessageDataProperties.Find(e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;
                    // Set the message Id
                    cloudMessage.MessageDataProperties.Add(new KeyValue(MessageDataMetaDataKey.Cpif_TargetName.ToString(), sessionId));
                    // Convert CloudMessage to memory stream
                    MemoryStream cloudStreamMessage = FileDataUtility.SerializeToStream(cloudMessage);
                    cloudStreamMessage.Position = 0;

                    // Convert CloudMessage payload to file stream
                    FileStream cdtfStreamData = (FileStream)dataStream;

                    string fileName = cloudMessage.MessageDataProperties.Find(e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;
                    // Uploade the data to cloud storage
                    bool isSuccess = new AzureCloudBlobSenderEngine().SendToBlobStorage(cdtfStreamData, sessionId);

                    if (isSuccess)
                    {
                        //Send the cloud message as stream 
                        SendToQueue(client, cloudStreamMessage,
                            subscriptionFilter, cloudMessage.DeliveryAddress, MetaDataFlag, sessionId, StreamLocation.InBlob.ToString());
                        //LogDataFacade.LogInfo(cloudMessage);

                        string filename = cloudMessage.MessageDataProperties.Find(e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;
                        string logMessage = "Message Successfully sent to the Azure Queue & Blob:- " + filename;
                        LogDataFacade.LogInfo(logMessage);

                    }
                }
                catch (Exception ex)
                {
                    LogDataFacade.LogErrors(ex.Message);
                }
            }
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Azures the service bus retry.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="method">The method.</param>
        /// <param name="isRecover">if set to <c>true</c> [is recover].</param>
        /// <returns>T.</returns>
        /// <exception cref="System.ArgumentNullException"></exception>
        private static T AzureServiceBusRetry<T>(Func<T> method, bool isRecover)
        {

            bool executionSuccess;
            int retryCount = 0;

            if (method == null)
                throw new ArgumentNullException("Method is not provided");

            T returnValue = default(T);

            do
            {
                try
                {
                    returnValue = method();
                    executionSuccess = true;

                    return returnValue;
                }
                catch (Exception ex)
                {
                    //Increment the retry account
                    retryCount++;
                    executionSuccess = false;

                    int secondsToWaitBeforeRetry = 10;
                    // Set the inner exception            
                    string innerException = ex.InnerException == null ? string.Empty : ex.InnerException.ToString();

                    Thread.Sleep(secondsToWaitBeforeRetry * 1000);
                }

            } while (!executionSuccess && isRecover);

            return returnValue;
        }

        /// <summary>
        /// Sends to queue.
        /// </summary>
        /// <param name="Sender">The sender.</param>
        /// <param name="subMessageStream">The sub message stream.</param>
        /// <param name="filterKey">The filter key.</param>
        /// <param name="filterValue">The filter value.</param>
        /// <param name="messageId">The message identifier.</param>
        /// <param name="sessionId">The session identifier.</param>
        /// <param name="dataStreamLocation">The data stream location.</param>
        private static void SendToQueue(dynamic Sender, Stream subMessageStream,
            string filterKey, string filterValue, string messageId, string sessionId, string dataStreamLocation)
        {
            AzureServiceBusRetry(() =>
            {
                // set the stream postion to 0
                if (subMessageStream.Position > 0)
                {
                    subMessageStream.Position = 0;
                }

                BrokeredMessage message = new BrokeredMessage(subMessageStream, true);
                message.MessageId = messageId;
                message.Properties[SessionId] = sessionId;
                message.Properties[filterKey] = filterValue;
                message.Properties[DataLocation] = dataStreamLocation;
                Sender.Send(message);

                return true;

            }, true);
        }
        #endregion
    }
}
