﻿using Cpif.Cloud.Common.DataContract;
using Cpif.Cloud.Common.Utility;
using Cpif.Cloud.Sender.Azure.Plugin.Contracts;
using Microsoft.Azure;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

namespace Cpif.Cloud.Sender.Azure.Plugin
{
    public class AzureCloudBlobSenderEngine
    {
        #region Config Keys
        private const string BufferSize = "BufferSize";
        private const string BlobConnection = "Microsoft.Storage.ConnectionString";
        private const string BlobContainerName = "ContainerName";
        #endregion

        #region Private Properties

        private string storageConnectionString = null;
        private string containerName = null;
        private int bufferSize = 0;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="AzureCloudBlobSenderEngine"/> class.
        /// </summary>
        public AzureCloudBlobSenderEngine()
        {
            storageConnectionString = CloudConfigurationManager.GetSetting(BlobConnection);
            containerName = CloudConfigurationManager.GetSetting(BlobContainerName);
            bufferSize = Convert.ToInt32(CloudConfigurationManager.GetSetting(BufferSize));
        }

        #region Public Methods

        /// <summary>
        /// Sends to BLOB storage.
        /// </summary>
        /// <param name="dataStream">The data stream.</param>
        /// <param name="dataFileName">Name of the data file.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool SendToBlobStorage(Stream dataStream, string dataFileName)
        {
            long bytesRead = 0;            
            byte[] byteStream = null;
            int count = 0;
            int blockItemCount = 0;
            long totalRead = 0;
            List<string> blockList = new List<string>();
            long blockSize = 0;
            string blockIdBase64 = string.Empty;
            bool isUploadSuccess = false;
            string blobUploadingMsg = "";
            string dataSizeMsg = "";

            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer blobContainer = blobClient.GetContainerReference(containerName);

            if (!blobContainer.Exists())
            {
                LogDataFacade.LogErrors("Error : "+ containerName + " Blob Container is not exist");
            }

            CloudBlockBlob dataBlockBlob = blobContainer.GetBlockBlobReference(dataFileName);

            long blockChunkSize = bufferSize * 1024;

            if (dataStream.Length < blockChunkSize)
            {
                blockChunkSize = dataStream.Length;
            }
            byte[] buffer = new byte[blockChunkSize];

            try
            {
                IEnumerable<string> uncommittedList = dataBlockBlob.Container.
                   ListBlobs(dataBlockBlob.Name, true, BlobListingDetails.UncommittedBlobs).Select(p => p.Uri.ToString()).
                   Except(dataBlockBlob.Container.ListBlobs(dataBlockBlob.Name, true).Select(p => p.Uri.ToString()));

                if (uncommittedList.AsQueryable().Count() > 0)
                {
                    foreach (var blockListItem in dataBlockBlob.DownloadBlockList(BlockListingFilter.Uncommitted))
                    {
                        byteStream = new byte[blockListItem.Length];
                        blockSize = blockSize + blockListItem.Length;
                        blockList.Add(blockListItem.Name);
                        blockItemCount++;
                    }

                    totalRead = blockSize;
                    count = Convert.ToInt32(totalRead / blockChunkSize);
                }
            }
            catch (Exception ex)
            {
                LogDataFacade.LogErrors("Error Occurred:- " + ex.Message);
            }

            try
            {
               // blobUploadingMsg = "Start BLOB Data Uploading";
                //LogDataFacade.LogInfo(blobUploadingMsg);

                while (totalRead < dataStream.Length)
                {
                    if ((dataStream.Length - totalRead) < blockChunkSize)
                    {
                        buffer = null;
                        buffer = new byte[dataStream.Length - totalRead];
                    }

                    dataStream.Seek(totalRead, SeekOrigin.Begin);
                    bytesRead = dataStream.Read(buffer, 0, buffer.Length);

                    blockIdBase64 = Convert.ToBase64String(System.BitConverter.GetBytes(count));
                    dataBlockBlob.PutBlock(blockIdBase64, new MemoryStream(buffer, true), null);

                    double uploadingSize = bytesRead / 1024;
                    dataSizeMsg = string.Concat(uploadingSize.ToString(), " KB");
                    //LogDataFacade.LogInfo(blobUploadingMsg);

                    blockList.Add(blockIdBase64);
                    count++;

                    totalRead = totalRead + bytesRead;
                }

                dataBlockBlob.PutBlockList(blockList);

                blobUploadingMsg = "Sent " + dataFileName +" - " + dataSizeMsg + " to Azure Blob";
                LogDataFacade.LogInfo(blobUploadingMsg);

                isUploadSuccess = true;
            }
            catch (Exception ex)
            {
                LogDataFacade.LogErrors("Warning : " + ex.Message);
            }
            finally
            {
                dataStream.Flush();
                dataStream.Close();
            }

            return isUploadSuccess;
        }
        #endregion

    }
}
