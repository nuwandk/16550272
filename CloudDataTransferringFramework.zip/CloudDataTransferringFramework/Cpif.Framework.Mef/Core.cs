﻿using Cpif.Framework.Mef.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;

namespace Cpif.Framework.Mef
{
    [Export(typeof(ICore))]
    public class Core : ICore
    {
        [ImportMany]
        private IEnumerable<Lazy<IOperation, IOperationCommand>> _operations;

        public string PerformOperations(bool data, string command)
        {
            foreach (Lazy<IOperation, IOperationCommand> i in _operations)
            {
                if (i.Metadata.Command.Equals(command))
                    return i.Value.Operate(data);
            }
            return "Unrecognized operation";
        }
    }
}