﻿using System;

namespace Cpif.Framework.Mef
{
    public interface ICore
    {
        String PerformOperations(bool data, string command);
    }
}