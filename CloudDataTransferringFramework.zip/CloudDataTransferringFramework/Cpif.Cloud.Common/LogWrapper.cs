﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Common.Logger
{
    public static class LogWrapper
    {
        private static readonly ILog debugLog = LogManager.GetLogger("DebugLog");
        private static readonly ILog infoLog = LogManager.GetLogger("InfoLog");
        private static readonly ILog errorLog = LogManager.GetLogger("ErrorLog");

        public static void LogDebug(string message, Exception ex = null)
        {
            if (debugLog == null)
                return;

            if (ex == null)
            {
                debugLog.Debug(message);
            }
            else
            {
                debugLog.Debug(message, ex);
            }
        }

        public static void LogInfo(string message, Exception ex = null)
        {
            if (infoLog == null)
                return;

            if (ex == null)
            {
                infoLog.Info(message);
            }
            else
            {
                infoLog.Info(message, ex);
            }
        }

        public static void LogErrorInfo(string message, Exception ex = null)
        {
            if (infoLog == null)
                return;

            if (ex == null)
            {
                errorLog.Error(message);
            }
            else
            {
                errorLog.Error(message, ex);
            }
        }

    }
}
