﻿using Microsoft.Azure;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cloud.Infrastructure.Setup.Application
{
    class Program
    {
        #region private constants

            private const string CLIENT_DATA_FILE = "ClentDataFile";
            private const string TOPIC_NAME = "topicName";
            private const string CONTAINER_NAME_LIST = "ContainerNameList";
            private const string ADDRESS_FILTER_EXPRESSION = "AddressFilterExpression";
            private const string RULE_NAME_FORMAT = "RuleNameFormat";
            private const string RULE_FILTER_PROPERTY = "RuleFilterProperty";
            private const string SUBSCRIPTION_NAME_FORMAT = "SubscriptionNameFormat";
            private const string CLIENT_ID_LIST = "ClientIdList";    
            private const string QUEUE_LIST = "QueueNameList";
            private const string SESSIONFULL = "sessionFull";    
        
  
        #endregion

        #region main method
        static void Main(string[] args)
        {
            Console.Title = "Cloud Infrastructure Setup Application";

            try
            {

                Console.WriteLine("Please Enter the Topic Name : ");
                //string topicName = Console.ReadLine();

                string topicName = ConfigurationManager.AppSettings[TOPIC_NAME];


                List<string> containerNameList = GetContainerNameList();
                List<string> clientList = GetClientIDList(ConfigurationManager.AppSettings[CLIENT_DATA_FILE]);
                bool sessionFull = Convert.ToBoolean(ConfigurationManager.AppSettings[SESSIONFULL]);
                bool isPartioningEnabled = Convert.ToBoolean(ConfigurationManager.AppSettings["EnablePartioning"]);
                //create queuelist 
                List<string> queueList = ConfigurationManager.AppSettings[QUEUE_LIST].Split(',').ToList();


                //Create the containers in list
                CreateContainerList(containerNameList);
                Console.WriteLine("BLOB Container creation completed successfully.");

                CreateQueue(queueList, sessionFull, isPartioningEnabled);
                Console.WriteLine("Queue creation completed successfully.");

                //creating the topic and the subscriptions
                CreateTopicAndSubscriptions(clientList, topicName, sessionFull, isPartioningEnabled);

                Console.WriteLine("Topic and Subscription creation completed  successfully.");
                Console.WriteLine("Press <Enter> to exit...");

                Console.ReadLine();
            }
            catch (Exception ex)
            {
                //TODO: handle the exception and log
                Console.WriteLine(string.Concat("Exception occuerd ", ex.Message));
                Console.WriteLine(string.Concat("Inner Excpetion ", ex.InnerException));
                Console.ReadLine();
            }             

        }
        #endregion

        #region private static methods

        /// <summary>
        /// Create topic and the subscriptions for clients
        /// </summary>
        /// <param name="clientList">client Id list </param>
        /// <param name="topicName">topic name</param>
        private static void CreateTopicAndSubscriptions(List<string> clientList, string topicName, bool requireSession, bool requirePartioning)
        {
            // Configure Topic Settings
            TopicDescription td = new TopicDescription(topicName) {
                EnablePartitioning= requirePartioning,
                MaxSizeInMegabytes = 5120
            };

            // Create a new Topic with custom settings
            string connectionString =
                CloudConfigurationManager.GetSetting("Microsoft.ServiceBus.ConnectionString");

            var namespaceManager =
                NamespaceManager.CreateFromConnectionString(connectionString);

            if (namespaceManager.TopicExists(topicName))
            {
                namespaceManager.DeleteTopic(topicName);
            }

            namespaceManager.CreateTopic(td);
            Console.WriteLine("The topic named {0} created successfully. ", topicName);
            foreach (var item in clientList)
            {
                if(!String.IsNullOrEmpty(item)){
                var creatingSubscription = new SubscriptionDescription(topicName, GetSubscriptionName(item))
                {
                    RequiresSession = requireSession,   
                    LockDuration= new TimeSpan(0, 0, 5, 0, 0)                    
                    
                };
                // Create a  filtered subscription for client

                var ruleDescription = new RuleDescription()
                {
                    Filter = new SqlFilter(GetFilterExpression(item)),
                    Name = GetRuleName(item)
                };

                namespaceManager.CreateSubscription(creatingSubscription, ruleDescription);
                Console.WriteLine("Subscription created with the rule for client {0}", item);}
            }
        }

        /// <summary>
        /// Create queue 
        /// </summary>  
        private static void CreateQueue(List<string> queueList, bool requireSession, bool requirePartioning)
        {
            // Create a new Queue with custom settings
            string connectionString = CloudConfigurationManager.GetSetting("Microsoft.ServiceBus.ConnectionString");

            var namespaceManager = NamespaceManager.CreateFromConnectionString(connectionString);

            foreach (var item in queueList)
            {
                if (!String.IsNullOrEmpty(item))
                {
                    // Configure Queue Settings
                    QueueDescription qd = new QueueDescription(item)
                    {
                        LockDuration = new TimeSpan(0, 0, 5, 0, 0),
                        RequiresSession = requireSession,
                        MaxSizeInMegabytes = 5120,
                        EnablePartitioning =  requirePartioning
                    };

                    if (namespaceManager.QueueExists(qd.Path))
                    {
                        namespaceManager.DeleteQueue(qd.Path);
                    }
                    namespaceManager.CreateQueue(qd);
                    Console.WriteLine("The queue named {0} created successfully. ", item);
                }
            }
        }

        /// <summary>
        /// Create the blob client and the containers for given conatainer name list
        /// </summary>
        /// <param name="containerNames">conatainer name list</param>
        private static void CreateContainerList(List<string> containerNames)
        {
            // Retrieve storage account from connection string.
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                CloudConfigurationManager.GetSetting("StorageConnectionString"));

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

            CloudBlobContainer container = null;

            foreach (var item in containerNames)
            {
                if (!String.IsNullOrEmpty(item))
                {
                    // Retrieve a reference to a container. 
                    container = blobClient.GetContainerReference(item);

                    // Create the container if it doesn't already exist.
                  //  container.DeleteIfExists();
                    container.CreateIfNotExists();

                    Console.WriteLine("The container named {0} created ", item);
                }

            }     
        }

        /// <summary>
        /// get the conatiner name list from the config
        /// </summary>
        /// <returns>string list</returns>
        private static List<string> GetContainerNameList() {
           return ConfigurationManager.AppSettings[CONTAINER_NAME_LIST].Split(',').ToList();        
        }

        /// <summary>
        /// Get the filter expression for the rule
        /// </summary>
        /// <param name="clientID">client id</param>
        /// <returns>string</returns>
        private static string GetFilterExpression(string clientID) {
            return ConfigurationManager.AppSettings[RULE_FILTER_PROPERTY]+" = '"+String.Format(ConfigurationManager.AppSettings[ADDRESS_FILTER_EXPRESSION], clientID)+"'";
        }

        /// <summary>
        /// return the rule name for given client
        /// </summary>
        /// <param name="clientID"></param>
        /// <returns></returns>
        private static string GetRuleName(string clientID)
        {
            return String.Format(ConfigurationManager.AppSettings[RULE_NAME_FORMAT], clientID, ConfigurationManager.AppSettings[RULE_FILTER_PROPERTY]);
        }
      
        /// <summary>
        /// Return the subscription name for given client
        /// </summary>
        /// <param name="clientID"></param>
        /// <returns></returns>
        private static string GetSubscriptionName(string clientID)
        {
            return String.Format(ConfigurationManager.AppSettings[SUBSCRIPTION_NAME_FORMAT], clientID);           
        }

        /// <summary>
        /// return the clientId list from the file in given path or the default list 
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        private static List<string> GetClientIDList(string filePath)
        {
            List<string> clientList = new List<string>();
            //Get the client list from the clientIds.txt file if it exists
            if (File.Exists(@filePath))
            {
                string contents = File.ReadAllText(@filePath);
                clientList = contents.Split(new string[] { Environment.NewLine }, StringSplitOptions.None).ToList();
            }
            else{
                //if the file not exists get clientIds frm config
                clientList = ConfigurationManager.AppSettings[CLIENT_ID_LIST].Split(',').ToList();
            }
            return clientList;
        }

        #endregion  
    }
}
