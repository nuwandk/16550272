﻿using Amazon.S3;
using Amazon.S3.Model;
using Cpif.Cloud.Common.Utility;
using System;
using System.Configuration;
using System.IO;
using System.Text;

namespace Cpif.Cloud.Receiver.Amazon.Plugin
{
    public class AmazonCloudS3BucketReceiverEngine
    {

        #region App config keys

        private const string AmazonS3BucketName = "Amazon.S3Bucket.Name";
        private string S3BucketName;

        #endregion

        #region Constants

        private const string TempFilePostFix = "_temp";
        private const string RecordDataPreFix = "Received";

        #endregion

        #region Constructor
        public AmazonCloudS3BucketReceiverEngine()
        {
            S3BucketName = ConfigurationManager.AppSettings[AmazonS3BucketName];
        }
        #endregion

        #region Public Methods

        /// <summary>Downloads the s3 bucket data.</summary>
        /// <param name="blobName">Name of the BLOB.</param>
        /// <param name="originalFileName">Name of the original file.</param>
        /// <param name="clientDownloadFolderPath">The client download folder path.</param>
        public void DownloadS3BucketData(IAmazonS3 client, string blobName, string originalFileName, string clientDownloadFolderPath)
        {
            string responseBody = "";
            //const string S3BucketName = "cpifs3bucket";

            GetObjectRequest request = new GetObjectRequest
            {
                BucketName = S3BucketName,
                Key = blobName
            };
            using (GetObjectResponse response = client.GetObject(request))
            using (Stream responseStream = response.ResponseStream)
            using (StreamReader reader = new StreamReader(responseStream))
            {
                string title = response.Metadata["x-amz-meta-title"]; // Assume you have "title" as medata added to the object.
                string contentType = response.Headers["Content-Type"];
                Console.WriteLine("Object metadata, Title: {0}", title);
                Console.WriteLine("Content type: {0}", contentType);

                responseBody = reader.ReadToEnd(); // Now you process the response body.
            }

            string filePath = Path.Combine(clientDownloadFolderPath, originalFileName);

            if (!Directory.Exists(clientDownloadFolderPath))
            {
                Directory.CreateDirectory(clientDownloadFolderPath);
            }

            //long payloadLength = GetBlobLength(container, blobName);

            // Oops we got a zero byte file.
            if (string.IsNullOrEmpty(responseBody))
            {
                // Create the file
                Utility.DeleteAndCreateEmptyDataFile(filePath);
            }
            // Delete the file
            DeleteObjectRequest deleteRequest = new DeleteObjectRequest()
            {
                BucketName = S3BucketName,
                Key = blobName
            };

            client.DeleteObject(deleteRequest);

            SetDownloadDataSettings(responseBody, clientDownloadFolderPath, originalFileName, blobName, responseBody.Length);

        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Sets the download data settings.
        /// </summary>
        /// <param name="responseBody">The response body.</param>
        /// <param name="clientDownloadFolderPath">The client download folder path.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="bucketName">Name of the bucket.</param>
        /// <param name="payloadLength">Length of the payload.</param>
        private void SetDownloadDataSettings(string responseBody, string clientDownloadFolderPath, string fileName, string bucketName, long payloadLength)
        {
            byte[] payloadData = new byte[payloadLength];
            long pathSize = 0;
            long startPos = 0;
            bool isAvailable = false;

            try
            {
                string tempFileName = string.Concat(fileName, TempFilePostFix);
                string downloadTempFolderPath = Path.Combine(clientDownloadFolderPath, tempFileName);
                string downloadOriginalFolderPath = Path.Combine(clientDownloadFolderPath, fileName);

                if (File.Exists(downloadTempFolderPath))
                {
                    using (var stream = new FileStream(downloadTempFolderPath, FileMode.Open))
                    {
                        pathSize = payloadLength - stream.Length;
                        startPos = stream.Length;
                        isAvailable = true;
                    }
                }
                else
                {
                    pathSize = payloadLength;
                    isAvailable = false;
                }

                //CloudBlockBlob payloadBlockBlob = container.GetBlockBlobReference(blobName);
                SaveBucketData(responseBody, downloadTempFolderPath, downloadOriginalFolderPath,
                    pathSize, payloadData, startPos, isAvailable);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Saves the bucket data.
        /// </summary>
        /// <param name="responseBody">The response body.</param>
        /// <param name="downloadTempFolderPath">The download temporary folder path.</param>
        /// <param name="downloadOriginalFolderPath">The download original folder path.</param>
        /// <param name="bucketLengthRm">The bucket length rm.</param>
        /// <param name="bytes">The bytes.</param>
        /// <param name="startPosition">The start position.</param>
        /// <param name="isAvailable">if set to <c>true</c> [is available].</param>
        private void SaveBucketData(string responseBody, string downloadTempFolderPath, string downloadOriginalFolderPath,
            long bucketLengthRm, byte[] bytes, long startPosition, bool isAvailable)
        {
            string saveDataLogMessage = "Start saving bucket data to disk";
            //LogDataFacade.LogInfo(saveDataLogMessage);

            try
            {
                if (isAvailable == true)
                {
                    using (FileStream fs = new FileStream(downloadTempFolderPath, FileMode.Append, FileAccess.Write))
                    {
                        byte[] blobContents = new UTF8Encoding(true).GetBytes(responseBody);
                        fs.Position = startPosition;
                        fs.Write(blobContents, 0, blobContents.Length);
                    }
                }
                else
                {
                    using (FileStream fs = new FileStream(downloadTempFolderPath, FileMode.OpenOrCreate))
                    {
                        byte[] blobContents = new UTF8Encoding(true).GetBytes(responseBody);
                        fs.Position = startPosition;
                        fs.Write(blobContents, 0, blobContents.Length);
                    }
                }

                double downloadingSize = bucketLengthRm / 1024;
                string s3FileName = Path.GetFileName(downloadOriginalFolderPath);
                string fileSizeMsg = string.Concat(downloadingSize.ToString(), " KB");
                //LogDataFacade.LogInfo(saveDataLogMessage);

                Utility.DeletePreviousFile(downloadOriginalFolderPath);

                File.Move(downloadTempFolderPath, downloadOriginalFolderPath);
                saveDataLogMessage = "Successfully Received Data From S3 Bucket:- " + s3FileName + " | Size:- " + fileSizeMsg;
                LogDataFacade.LogInfo(saveDataLogMessage);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

    }
}
