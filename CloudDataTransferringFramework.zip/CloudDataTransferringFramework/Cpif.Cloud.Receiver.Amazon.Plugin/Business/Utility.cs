﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Receiver.Amazon.Plugin
{
    public static class Utility
    {
        /// <summary>
        ///   <para></para>
        ///   <para>Deletes the previous file.
        /// </para>
        /// </summary>
        /// <param name="fullFilePath">The full file path.</param>
        public static void DeletePreviousFile(string fullFilePath)
        {
            FileInfo filInfo = new FileInfo(fullFilePath);

            if (filInfo.Exists)
            {
                filInfo.Delete();
            }
        }

        /// <summary>
        /// Deletes the and create empty data file.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        public static void DeleteAndCreateEmptyDataFile(string filePath)
        {
            DeletePreviousFile(filePath);
            File.Create(filePath).Dispose();
        }

        /// <summary>Writes the data to disk.</summary>
        /// <param name="fullFilePath">The full file path.</param>
        /// <param name="cdtfStreamData">The CDTF stream data.</param>
        public static void WriteFileStreamData(string fullFilePath, Stream cdtfStreamData)
        {
            FileInfo file = new FileInfo(fullFilePath);
            if (!Directory.Exists(file.Directory.FullName))
                file.Directory.Create();

            Utility.DeletePreviousFile(fullFilePath);

            using (FileStream fs = new FileStream(fullFilePath, FileMode.OpenOrCreate))
            {
                byte[] bytesInStream = new byte[cdtfStreamData.Length];
                cdtfStreamData.Read(bytesInStream, 0, bytesInStream.Length);
                // Use write method to write to the file specified above
                fs.Write(bytesInStream, 0, bytesInStream.Length);
            }
        }
    }
}
