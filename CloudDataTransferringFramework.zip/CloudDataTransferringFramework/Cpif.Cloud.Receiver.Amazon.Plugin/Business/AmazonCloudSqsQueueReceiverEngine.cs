﻿using Amazon.S3;
using Amazon.SQS;
using Amazon.SQS.Model;
using Cpif.Cloud.Common.DataContract;
using Cpif.Cloud.Common.Utility;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Threading;

namespace Cpif.Cloud.Receiver.Amazon.Plugin
{
    public class AmazonCloudSqsQueueReceiverEngine : IReceiver
    {
        #region App config keys

        private const string DataRecordingLocation = "DataRecordingLocation";
        private const string AmazonSQSQueueUrl = "Amazon.SQSQueue.Url";
        private const string DownloadFolderPath = "DownloadFolderPath";
        #endregion

        #region Constants

        private const string DataLocation = "DataLocation";
        private const string SessionId = "SessionId";
        private const string MessageId = "MessageId";
        private const string FileName = "FileName";
        private const string TempFilePostFix = "_temp";
        private const string RecordDataPreFix = "Received";
        private const string MetaDataFlag = "1";
        private const string PayloadFlag = "2";

        #endregion

        #region Private Properties

        private bool isArchive;
        private string dataRecordingLocation;
        private static IAmazonS3 client;
        private string SqsQueueUrl = ConfigurationManager.AppSettings[AmazonSQSQueueUrl]; //"https://sqs.us-east-2.amazonaws.com/146677488329/CpifQueue";
        #endregion

        #region Constructor

        public AmazonCloudSqsQueueReceiverEngine()
        {
            this.dataRecordingLocation = ConfigurationManager.AppSettings[DataRecordingLocation];
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Receives the message.
        /// </summary>
        /// <param name="isQueueClient">if set to <c>true</c> [is queue client].</param>
        public void ReceiveMessage(bool isQueueClient)
        {         
            try
            {
                AmazonSQSClient sqsClient = new AmazonSQSClient();
                client = new AmazonS3Client();

                ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest();
                receiveMessageRequest.QueueUrl = SqsQueueUrl;
                List<string> AttributesList = new List<string>();
                AttributesList.Add(DataLocation);
                AttributesList.Add(SessionId);
                AttributesList.Add(MessageId);
                AttributesList.Add(FileName);

                //Assign list and QueueURL to request
                receiveMessageRequest.MessageAttributeNames = AttributesList;

                string downloadFolderPath = ConfigurationManager.AppSettings[DownloadFolderPath];
                List<CpifCloudMessage> metaDataList = new List<CpifCloudMessage>();

                while (true)
                {
                    var receivedMessage = sqsClient.ReceiveMessage(receiveMessageRequest);
                    if (receivedMessage.Messages.Count > 0)
                    {
                        foreach (var message in receivedMessage.Messages)
                        {
                            try
                            {
                                Console.WriteLine($"Received MessageId: {message.MessageId}");
                                Dictionary<string, MessageAttributeValue> messageAttributes = message.MessageAttributes;

                                string dataLocation = messageAttributes[DataLocation].StringValue;
                                string sessionId = messageAttributes[SessionId].StringValue;
                                string messageId = messageAttributes[MessageId].StringValue;

                                ////////////////////////////////////////////////////////////////////////////////////////////////////////
                                CpifCloudMessage cloudMessage;

                                if (dataLocation.Equals(StreamLocation.InMessage.ToString()))
                                {
                                    if (messageId == MetaDataFlag)
                                    {
                                        string base64encodedstring = message.Body;
                                        var bytes = Convert.FromBase64String(base64encodedstring);
                                        var metaDataMessageStream = new MemoryStream(bytes);

                                        cloudMessage = (CpifCloudMessage)FileDataUtility.DeserializeDataStream(metaDataMessageStream);
                                        metaDataList.Add(cloudMessage);
                                        CompleteQueueMessageRequest(SqsQueueUrl, sqsClient, message);
                                    }
                                    else
                                    {
                                        CpifCloudMessage metaDataMessage = metaDataList.Find(e => e.SessionDataId.Equals(sessionId));

                                        if (metaDataMessage != null)
                                        {
                                            string base64encodedstring = message.Body;
                                            var bytes = Convert.FromBase64String(base64encodedstring);
                                            Stream dataStream = new MemoryStream(bytes);
                                            string originalFileName = metaDataMessage.MessageDataProperties.Find
                                            (e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;

                                            string fullFilePath = Path.Combine(downloadFolderPath, originalFileName);

                                            Utility.WriteFileStreamData(fullFilePath, dataStream);

                                            metaDataList.Remove(metaDataMessage);
                                            CompleteQueueMessageRequest(SqsQueueUrl, sqsClient, message);

                                            LogDataFacade.LogInfo(string.Concat("Successfully Receive The Data From SQS Queue: ", originalFileName));
                                            FileDataUtility.ArchiveData(isArchive, dataRecordingLocation, originalFileName, RecordDataPreFix);
                                        }
                                        else
                                        {

                                            // receivedMessage.Abandon();
                                        }
                                    }
                                }
                                else
                                {
                                    string base64encodedstring = message.Body;
                                    var bytes = Convert.FromBase64String(base64encodedstring);
                                    Stream metaDataMessageStream = new MemoryStream(bytes);

                                    cloudMessage = (CpifCloudMessage)FileDataUtility.DeserializeDataStream(metaDataMessageStream);
                                    string bucketName = sessionId;
                                    string originalFileName = cloudMessage.MessageDataProperties.Find
                                        (e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;

                                    // Download the blob data
                                    new AmazonCloudS3BucketReceiverEngine().DownloadS3BucketData(client, bucketName, originalFileName, downloadFolderPath);
                                    CompleteQueueMessageRequest(SqsQueueUrl, sqsClient, message);

                                }
                            }
                            catch (Exception ex)
                            {
                                //receivedMessage.Abandon();
                                LogDataFacade.LogErrors("Data Download Error :" + ex.Message, ex.StackTrace);
                            }

                        }
                    }
                    Thread.Sleep(500);
                }
            }
            catch (Exception ex)
            {
                LogDataFacade.LogErrors("Error :" + ex.Message, ex.StackTrace);
                throw ex;
            }
        }

        #endregion

        #region Private Methods

        /// <summary>Completes the queue message request.</summary>
        /// <param name="queueUrl">The queue URL.</param>
        /// <param name="sqsClient">The SQS client.</param>
        /// <param name="message">The message.</param>
        private void CompleteQueueMessageRequest(string queueUrl, AmazonSQSClient sqsClient, Message message)
        {
            var messageReceiptHandle = message.ReceiptHandle;
            DeleteMessageRequest deleteMessageRequest = new DeleteMessageRequest();
            deleteMessageRequest.QueueUrl = queueUrl;
            deleteMessageRequest.ReceiptHandle = messageReceiptHandle;
            sqsClient.DeleteMessage(deleteMessageRequest);
            Thread.Sleep(500);
        }

        #endregion
    }
}
