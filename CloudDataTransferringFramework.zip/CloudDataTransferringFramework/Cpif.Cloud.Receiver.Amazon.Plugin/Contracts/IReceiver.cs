﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Receiver.Amazon.Plugin
{
    public interface IReceiver
    {
        void ReceiveMessage(bool isQueueClient);
    }
}
