﻿using Cpif.Cloud.Common.Utility;
using Cpif.Cloud.Common.DataContract;
using Cpif.Framework.Mef.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Receiver.Amazon.Plugin
{
    [Export(typeof(IOperation))]
    [ExportMetadata("Command", "AmazonCloudReceiveProcessor")]
    public class AmazonCloudReceiveProcessor : IOperation
    {
        public string Operate(bool IsQueue)
        {
            try
            {
                AmazonCloudSqsQueueReceiverEngine receiver = new AmazonCloudSqsQueueReceiverEngine();
                // Data Received from the Queue
                receiver.ReceiveMessage(true);

                return "Successfully received the message";
            }
            catch (Exception ex)
            {
                LogDataFacade.LogErrors("Error Occurred:- " + ex.Message, ex.StackTrace);
                return "Error Occurred:- " + ex.Message;
            }

        }
    }
}


