﻿using Cpif.Cloud.Common.DataContract;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;

namespace Cpif.Cloud.Common.Utility
{
    public sealed class FileDataUtility
    {
        #region Constants

        private const string Priority = "Medium";
        private const string MsgType = "Cloud_Data";
        private const string deliveryAddresssSuffix = "ID-";
        #endregion

        #region Public Methods

        /// <summary>
        /// Creates the cloud data message.
        /// </summary>
        /// <param name="payloadPath">The payload path.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="originalLocation">The original location.</param>
        /// <param name="senderName">Name of the sender.</param>
        /// <returns>CpifCloudMessage.</returns>
        public static CpifCloudMessage CreateCloudDataMessage(string payloadPath, string originalLocation, string senderName)
        {
            string fileName = Path.GetFileName(payloadPath);
            string clientId = (payloadPath.Split('_').ElementAtOrDefault(1)).Split('-').LastOrDefault();  
            CpifCloudMessage cloudMessage = new CpifCloudMessage();

            cloudMessage.ActualData = GetFileDataStream(payloadPath);
            cloudMessage.Identifier = Guid.NewGuid().ToString();
            cloudMessage.DeliveryAddress = string.Concat(deliveryAddresssSuffix, clientId);
            cloudMessage.MessageType = MsgType;

            SetMessageDataMetaData(ref cloudMessage, originalLocation, fileName);
            SetMessageDeliveryMetaData(ref cloudMessage, originalLocation, fileName, clientId, senderName);

            return cloudMessage;
        }


        /// <summary>
        /// Gets the data files.
        /// </summary>
        /// <param name="folderLocation">The folder location.</param>
        /// <param name="messagesList">The messages list.</param>
        /// <param name="selectedMsgList">The picked message list.</param>
        /// <returns>System.String.</returns>
        public static string GetDataFiles(string folderLocation, ref List<string> messagesList, ref List<string> selectedMsgList)
        {
            var selectedItem = string.Empty;
            if (messagesList.Count > 0)
            {
                lock (messagesList)
                {
                    foreach (var item in messagesList)
                    {
                        lock (selectedMsgList)
                        {
                            if (!selectedMsgList.Contains(item))
                            {
                                selectedItem = item;
                                selectedMsgList.Add(item);
                                break;
                            }
                        }
                    }
                }
            }
             
            return selectedItem;
        }


        /// <summary>
        /// Gets the files from folder.
        /// </summary>
        /// <param name="folderLocation">The folder location.</param>
        /// <returns>List&lt;System.String&gt;.</returns>
        public static List<string> GetFilesFromFolder(string folderLocation)
        {
            //Get all files in the directory to list
            List<string> messages = new List<string>();
            if (Directory.Exists(@folderLocation))
            {
                messages = new List<string>(Directory.EnumerateFiles(@folderLocation));
            }
            return messages;
        }

        /// <summary>
        /// Deletes the delivered file.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        public static void DeleteDeliveredFile(string fileName)
        {
            while (true)
            {
                try
                {
                    FileStream f = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write, FileShare.Delete);
                    f.Close();
                    f.Dispose();
                    break;
                }
                catch (IOException ex)
                {
                    Thread.Sleep(250);
                }
            }

            //Console.WriteLine("deleting "+ fileName);
            if ((System.IO.File.Exists(@fileName)))
            {
                System.IO.File.Delete(@fileName);
            }
        }

        /// <summary>
        /// Archives the data.
        /// </summary>
        /// <param name="isArchive">if set to <c>true</c> [is archive].</param>
        /// <param name="dataRecordingLocation">The data recording location.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="fileNamePrifix">The file name prifix.</param>
        public static void ArchiveData(bool isArchive, string dataRecordingLocation, string fileName, string fileNamePrifix)
        {
            string record = string.Concat(fileName, ",", DateTime.Now);
            string recordFileName = string.Concat(fileNamePrifix, "_", DateTime.Now.ToString("yyyy-MM-dd"), ".txt");
            string path = Path.Combine(dataRecordingLocation, recordFileName);

            if (isArchive)
            {
                using (StreamWriter sw = File.AppendText(path))
                {
                    sw.WriteLine(record);
                }
            }
        }

        /// <summary>
        /// Serializes to stream.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <returns>MemoryStream.</returns>
        public static MemoryStream SerializeToStream(object message)
        {
            MemoryStream stream = new MemoryStream();
            IFormatter formatter = new BinaryFormatter();
            formatter.Serialize(stream, message);
            return stream;
        }


        /// <summary>
        /// Deserialize the data stream.
        /// </summary>
        /// <param name="stream">The stream.</param>
        /// <returns>System.Object.</returns>
        public static object DeserializeDataStream(Stream stream)
        {
            IFormatter formatter = new BinaryFormatter();
            stream.Seek(0, SeekOrigin.Begin);
            object message = formatter.Deserialize(stream);
            return message;
        }

        #endregion

        #region Private Methods

        private static string GetIpAddress()
        {
            string hostName = Dns.GetHostName(); // Retrive the Name of HOST  
            return Dns.GetHostByName(hostName).AddressList[0].ToString();
        }
        /// <summary>
        /// Gets the file data stream.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns>FileStream.</returns>
        private static FileStream GetFileDataStream(string path)
        {
            FileStream fileStream = null;

            //Wait and read until file lock released
            for (;;)
            {
                try
                {
                    fileStream = new FileStream(path, FileMode.Open, FileAccess.Read);
                    break;
                }
                catch (Exception ex)
                {
                    //Pass
                }
            }
            fileStream.Position = 0;
            return fileStream;
        }


        /// <summary>
        /// Sets the message data meta data.
        /// </summary>
        /// <param name="cloudMessage">The cloud message.</param>
        /// <param name="originalLocation">The original location.</param>
        /// <param name="fileName">Name of the file.</param>
        private static void SetMessageDataMetaData(ref CpifCloudMessage cloudMessage, string originalLocation, string fileName)
        {
            cloudMessage[MessageDataMetaDataKey.Cpif_OriginalLocation] = originalLocation;
            cloudMessage[MessageDataMetaDataKey.Cpif_OriginalName] = fileName;
            cloudMessage[MessageDataMetaDataKey.Cpif_PayloadLength] = cloudMessage.ActualData.Length.ToString();
        }

        /// <summary>
        /// Sets the message delivery meta data.
        /// </summary>
        /// <param name="cloudMessage">The cloud message.</param>
        /// <param name="originalLocation">The original location.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="clientId">The client identifier.</param>
        /// <param name="senderName">Name of the sender.</param>
        private static void SetMessageDeliveryMetaData(ref CpifCloudMessage cloudMessage, string originalLocation,
            string fileName, string clientId, string senderName)
        {
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_CountryCode] = fileName.Split('_').ElementAtOrDefault(0);
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_DeliveryMechanism] = "Cloud";
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_GenerateControlFile] = Boolean.TrueString.ToString();
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_OriginatorType] = "Dir";
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_Priority] = Priority;
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_RetainOriginalExtension] = Boolean.FalseString.ToString();
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_SenderAddress] = fileName.Split('_').ElementAtOrDefault(2);
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_SenderId] = clientId;
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_SenderIPAddresses] = GetIpAddress();
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_SenderName] = senderName;
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_SentTimestamp] = DateTime.UtcNow.ToString();
            cloudMessage[MessageDeliveryMetaDataKey.Cpif_StoreNumber] = clientId;
        }

        #endregion
    }
}
