﻿using Cpif.Cloud.Common.DataContract;
using Cpif.Cloud.Common.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Common.Utility
{
    public sealed class LogDataFacade
    {

        /// <summary>
        /// This method used to display the warning message 
        /// </summary>
        /// <param name="cloudMessage"></param>
        public static void LogErrors(string message, string stackTrace = "")
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(message);
            Console.ResetColor();
            LogWrapper.LogInfo(message);
            LogWrapper.LogErrorInfo(message + "\n " + stackTrace);
        }

        /// <summary>
        /// This method used to display the message sent status 
        /// </summary>
        /// <param name="cloudMessage"></param>
        public static void LogInfo(String message)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(message);
            Console.ResetColor();
            LogWrapper.LogInfo(message);
        }
    }
}
