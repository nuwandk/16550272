﻿namespace Cpif.Framework.Mef.Interfaces
{
    public interface IOperation
    {
        string Operate(bool IsQueue);
    }
}