﻿using System;

namespace Cpif.Framework.Mef.Interfaces
{
    public interface IOperationCommand
    {
        String Command { get; }
    }
}