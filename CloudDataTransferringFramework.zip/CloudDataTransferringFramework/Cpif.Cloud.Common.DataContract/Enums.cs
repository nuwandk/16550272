﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Common.DataContract
{

    #region Public Enums

    /// <summary>
    /// Stream Location types
    /// </summary>
    [Serializable]
    public enum StreamLocation
    {
        /// <summary>
        /// Represents data stream in message.
        /// </summary>
        InMessage,

        /// <summary>
        /// Represents data stream in blob.
        /// </summary>
        InBlob,

        /// <summary>
        /// Represents data stream in bucket.
        /// </summary>
        InBucket
    }

    /// <summary>
    /// Enum Message Data Meta Data Key
    /// </summary>
    [Serializable]
    public enum MessageDataMetaDataKey

    {
        Cpif_OriginalLocation,
        Cpif_OriginalName,
        Cpif_TargetName,
        Cpif_PayloadLength
    }

    /// <summary>
    /// Enum Message delivery Meta Data Key
    /// </summary>
    [Serializable]
    public enum MessageDeliveryMetaDataKey
    {
        Cpif_DeliveryMechanism,
        Cpif_Priority,
        Cpif_CountryCode,
        Cpif_StoreNumber,
        Cpif_OriginatorType,
        Cpif_SenderAddress,
        Cpif_SenderId,
        Cpif_SenderName,
        Cpif_GenerateControlFile,
        Cpif_RetainOriginalExtension,
        Cpif_SentTimestamp,
        Cpif_SenderIPAddresses,
    }

    #endregion

}
