﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Common.DataContract
{
    /// <summary>
    /// This class implements IComparer generic interface and defines specific implementation for
    /// comparing KeyValue object pairs.
    /// </summary>
    public class DataComparer : IComparer<KeyValue>
    {
        // Case insensitive comparer object to compare Key of key-value pairs.
        CaseInsensitiveComparer comparer = new CaseInsensitiveComparer();

        #region IComparer Members

        /// <summary>
        /// This methods gives custom comparison for KeyValue objects.
        /// </summary>
        /// <param name="x">First KeyValue object.</param>
        /// <param name="y">Second KeyValue object.</param>
        /// <returns>Less than zero - firstPair object less than secondPair object.
        ///          Zero - objects are equal.
        ///          More than zero - firstPair object more than secondPair object.
        /// </returns>
        public int Compare(KeyValue x, KeyValue y)
        {
            if (x == null)
            {
                throw new ArgumentNullException();
            }

            if (y == null)
            {
                throw new ArgumentNullException();
            }

            return comparer.Compare(x.Key.ToString(), y.Key.ToString());
        }

        #endregion

    }
}
