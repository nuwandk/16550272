﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Common.DataContract
{
    [Serializable]
    public class KeyValue
    {
        #region Public Properties

        // Holds the name of the key
        public string elementKey { get; set; }

        // Holds the value of the key
        public string elementValue { get; set; }

        #endregion Public Properties

        #region Public Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        public KeyValue()
        {
        }

        /// <summary>
        /// Initiates with values for Key/Value.
        /// </summary>
        /// <param name="key">Key.</param>
        /// <param name="name">Value.</param>
        public KeyValue(string key, string name)
        {
            elementKey = key;
            elementValue = name; 
        }

        #endregion

        #region Public Properties

        /// <summary>
        /// Key of RdmMessage metadata.
        /// </summary>
        public string Key
        {
            get
            {
                return elementKey;
            }
            set
            {
                elementKey = value;
            }
        }

        /// <summary>
        /// Value of RdmMessage metadata.
        /// </summary>
        public string Value
        {
            get
            {
                return elementValue;
            }
            set
            {
                elementValue = value;
            }
        }
        
        #endregion
    }
}
