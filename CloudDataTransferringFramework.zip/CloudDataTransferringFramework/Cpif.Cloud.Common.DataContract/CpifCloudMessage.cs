﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Cpif.Cloud.Common.DataContract
{
    [Serializable]
    public class CpifCloudMessage
    {

        #region Public Fields

        public List<KeyValue> MessageDataProperties = new List<KeyValue>();
        public List<KeyValue> MessageDeliveryProperties = new List<KeyValue>();
        public Stream ActualData { get; set; }
        public String SessionDataId { get; set; }
        public string Identifier { get; set; }
        public string DeliveryAddress { get; set; }
        public string MessageType { get; set; }

        public string this[MessageDataMetaDataKey contentMetaDataKey]
        {
            get
            {
                return GetMetaDataValue(MessageDataProperties, contentMetaDataKey.ToString());
            }
            set
            {
                SetMetaDataValue(MessageDataProperties, contentMetaDataKey.ToString(),
                    value.ToString());
            }
        }

        public string this[MessageDeliveryMetaDataKey transferMetaDataKey]
        {
            get
            {

                return GetMetaDataValue(MessageDeliveryProperties,
                    transferMetaDataKey.ToString());
            }
            set
            {
                SetMetaDataValue(MessageDeliveryProperties, transferMetaDataKey.ToString(),
                    value.ToString());
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Gets the index of the meta data item.
        /// </summary>
        /// <param name="metaDataList">The meta data list.</param>
        /// <param name="metaDataKey">The meta data key.</param>
        /// <returns>System.Int32.</returns>
        private static int GetMetaDataItemIndex(List<KeyValue> metaDataList, string metaDataKey)
        {
            metaDataList.Sort(new DataComparer());
            return metaDataList.BinarySearch(new KeyValue(metaDataKey, string.Empty), new DataComparer());
        }

        /// <summary>
        /// Sets the meta data value.
        /// </summary>
        /// <param name="metaDataList">The meta data list.</param>
        /// <param name="metaDataKey">The meta data key.</param>
        /// <param name="metaDataValue">The meta data value.</param>
        /// <exception cref="System.ArgumentNullException">Meta data is null or empty</exception>
        private static void SetMetaDataValue(List<KeyValue> metaDataList, string metaDataKey, string metaDataValue)
        {
            if (String.IsNullOrEmpty(metaDataKey) || metaDataList == null)
            {
                throw new ArgumentNullException("Meta data is null or empty ");
            }

            if (String.IsNullOrEmpty(metaDataValue))
            {
                metaDataValue = String.Empty;
            }

            KeyValue cloudKeyValue = new KeyValue(metaDataKey, metaDataValue);
            int listIndex = GetMetaDataItemIndex(metaDataList, metaDataKey);

            if (listIndex > -1)
            {
                metaDataList[listIndex] = cloudKeyValue;
            }
            else
            {
                metaDataList.Add(cloudKeyValue);

            }
        }

        /// <summary>
        /// Gets the meta data value.
        /// </summary>
        /// <param name="metaDataList">The meta data list.</param>
        /// <param name="metaDataKey">The meta data key.</param>
        /// <returns>System.String.</returns>
        /// <exception cref="System.ArgumentNullException">Meta data is null or empty</exception>
        private static string GetMetaDataValue(List<KeyValue> metaDataList, string metaDataKey)
        {
            if (String.IsNullOrEmpty(metaDataKey) || metaDataList == null)
            {
                throw new ArgumentNullException("Meta data is null or empty ");
            }
            int listIndex = GetMetaDataItemIndex(metaDataList, metaDataKey);

            if (listIndex > -1)
            {
                return metaDataList[listIndex].Value.ToString();
            }

            return string.Empty;
        }
        #endregion
    }
}
