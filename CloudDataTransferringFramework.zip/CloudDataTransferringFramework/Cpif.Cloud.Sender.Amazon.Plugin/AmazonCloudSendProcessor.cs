﻿using Cpif.Cloud.Common.Utility;
using Cpif.Cloud.Common.DataContract;
using Cpif.Framework.Mef.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Cpif.Cloud.Sender.Amazon.Plugin
{
    [Export(typeof(IOperation))]
    [ExportMetadata("Command", "AmazonCloudSendProcessor")]
    public class AmazonCloudSendProcessor : IOperation
    {
        private const string SendFolder = "FolderLocation";
        private static List<string> messagesList = new List<string>();
        private static List<string> pickedMessageList = new List<string>();
        private static string originalLocation = "Sender Side";
        private static string senderName = "Amazon Cloud Sender";

        public string Operate(bool IsQueue)
        {
            string folderLocation = ConfigurationManager.AppSettings[SendFolder].ToString();
            while (true)
            {
                try
                {
                    messagesList = FileDataUtility.GetFilesFromFolder(folderLocation);
                    string payloadPath = FileDataUtility.GetDataFiles(folderLocation, ref messagesList, ref pickedMessageList);
                    try
                    {
                        if (!String.IsNullOrEmpty(payloadPath))
                        {
                            CpifCloudMessage message = FileDataUtility.CreateCloudDataMessage(payloadPath, originalLocation, senderName);
                            AmazonCloudSqsQueueSenderEngine dataSender = new AmazonCloudSqsQueueSenderEngine();
                            // Data Send to Queue
                            dataSender.SendMessage(message, true);

                            //Force clean up
                            GC.Collect();
                            pickedMessageList.Remove(payloadPath);
                            FileDataUtility.DeleteDeliveredFile(payloadPath);
                        }
                    }
                    catch (Exception ex)
                    {
                        LogDataFacade.LogErrors("Error Occurred in picked file:- " + ex.Message, ex.StackTrace);
                        pickedMessageList.Remove(payloadPath);
                        FileDataUtility.DeleteDeliveredFile(payloadPath);
                    }
                }
                catch (Exception ex)
                {
                    LogDataFacade.LogErrors("Error Occurred:- " + ex.Message, ex.StackTrace);
 
                }
                Thread.Sleep(200);
            }
        }
    }
}

