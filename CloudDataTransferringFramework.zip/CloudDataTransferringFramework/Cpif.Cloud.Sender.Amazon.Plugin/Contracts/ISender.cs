﻿using Cpif.Cloud.Common.DataContract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Sender.Amazon.Plugin
{
    public interface ISender
    {
        void SendMessage(CpifCloudMessage cloudMessage, bool isQueueClient);
    }
}
