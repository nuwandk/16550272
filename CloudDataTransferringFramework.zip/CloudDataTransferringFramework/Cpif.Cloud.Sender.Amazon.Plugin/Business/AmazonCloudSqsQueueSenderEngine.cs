﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cpif.Cloud.Common.DataContract;
using Amazon.SQS;
using Amazon.SQS.Model;
using System.Xml.Serialization;
using System.Xml;
using System.IO;
using Cpif.Cloud.Common.Utility;
using Amazon.S3;
using Amazon.S3.Transfer;
using System.Data;
using System.Configuration;

namespace Cpif.Cloud.Sender.Amazon.Plugin
{
    public class AmazonCloudSqsQueueSenderEngine : ISender
    {
        #region Config Keys

        private const string MessageBodySize = "MessageBodySizeInKB";
        private const string AmazonSQSQueueUrl = "Amazon.SQSQueue.Url";

        #endregion

        #region Constants

        private const string MetaDataFlag = "1";
        private const string PayloadFlag = "2";

        #endregion

        #region Public Methods
        /// <summary>
        /// Sends the message.
        /// </summary>
        /// <param name="cloudMessage">The cloud message.</param>
        /// <param name="isQueueClient">if set to <c>true</c> [is queue client].</param>
        public void SendMessage(CpifCloudMessage cloudMessage, bool isQueueClient)
        {
            AmazonSQSClient client;

            // Create a unique message Id.
            string sessionId = Guid.NewGuid().ToString();

            if (isQueueClient)
            {
                client = new AmazonSQSClient();
            }
            else
            {
                client = null;

            }

            // Get the message body size and convert it to bytes
            int messageBodySize = Int32.Parse(ConfigurationManager.AppSettings[MessageBodySize]) * 1024;

            if (cloudMessage.ActualData.Length <= messageBodySize)
            {
                try
                {
                    string fileName = cloudMessage.MessageDataProperties.Find(e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;
                    cloudMessage.SessionDataId = sessionId;

                    byte[] fileBytes = new byte[cloudMessage.ActualData.Length];
                    cloudMessage.ActualData.Read(fileBytes, 0, Convert.ToInt32(cloudMessage.ActualData.Length));

                    string payloadDataBase64String = Convert.ToBase64String(fileBytes,
                                               Base64FormattingOptions.InsertLineBreaks);

                    cloudMessage.ActualData = new MemoryStream();
                    // Convert CloudMessage to memory stream
                    MemoryStream cloudMetaDataStreamMessage = FileDataUtility.SerializeToStream(cloudMessage);
                    cloudMetaDataStreamMessage.Position = 0;
                    string metaDataBase64String = Convert.ToBase64String(cloudMetaDataStreamMessage.ToArray());

                    //Send the cloud meta data message as stream 
                    SendToQueue(client, metaDataBase64String, sessionId, fileName, MetaDataFlag, StreamLocation.InMessage.ToString());
                    //Send the cloud payload message as stream 
                    SendToQueue(client, payloadDataBase64String, sessionId, fileName, PayloadFlag, StreamLocation.InMessage.ToString());

                    //LogDataFacade.LogInfo(cloudMessage);
                    string filename = cloudMessage.MessageDataProperties.Find(e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;
                    string logMessage = "Message Successfully sent to the SQS Queue:- " + filename;
                    LogDataFacade.LogInfo(logMessage);

                    //  UtilityManager.RecordSendData(isDataRecording, dataRecordingLocation, fileName, RECORD_PRI_FIX);
                }
                catch (Exception ex)
                {
                    LogDataFacade.LogErrors(ex.Message);
                }
            }
            else
            {
                try
                {
                    Stream dataStream = cloudMessage.ActualData;
                    // Set the file name as the target name
                    sessionId = cloudMessage.MessageDataProperties.Find(e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;
                    // Set the message Id
                    cloudMessage.MessageDataProperties.Add(new KeyValue(MessageDataMetaDataKey.Cpif_TargetName.ToString(), sessionId));

                    cloudMessage.ActualData = new MemoryStream();
                    // Convert CloudMessage to memory stream
                    MemoryStream cloudMetaDataStreamMessage = FileDataUtility.SerializeToStream(cloudMessage);
                    cloudMetaDataStreamMessage.Position = 0;
                    string metaDataBase64String = Convert.ToBase64String(cloudMetaDataStreamMessage.ToArray());

                    // Convert CloudMessage payload to file stream
                    FileStream cdtfStreamData = (FileStream)dataStream;

                    string fileName = cloudMessage.MessageDataProperties.Find(e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;

                    bool isSuccess = new AmazonCloudS3BucketSenderEngine().SendToBucket(cdtfStreamData, fileName);

                    if (isSuccess)
                    {
                        //Send the cloud message as stream 
                        SendToQueue(client, metaDataBase64String, sessionId, fileName, MetaDataFlag, StreamLocation.InBucket.ToString());

                        //LogDataFacade.LogInfo(cloudMessage);
                        string filename = cloudMessage.MessageDataProperties.Find(e => e.elementKey.Equals(MessageDataMetaDataKey.Cpif_OriginalName.ToString())).elementValue;
                        string logMessage = "Message Successfully sent to the SQS Queue & S3 Bucket:- " + filename;
                        LogDataFacade.LogInfo(logMessage);

                    }
                }
                catch (Exception ex)
                {
                    LogDataFacade.LogErrors(ex.Message);
                }

            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Sends to queue.
        /// </summary>
        /// <param name="sqsClient">The SQS client.</param>
        /// <param name="cloudMessage">The cloud message.</param>
        /// <param name="sessionId">The session identifier.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="messageId">The message identifier.</param>
        /// <param name="dataStreamLocation">The data stream location.</param>
        private void SendToQueue(dynamic sqsClient, string cloudMessage, string sessionId, string fileName, string messageId, string dataStreamLocation)
        {
            //const string SqsQueueUrl = "https://sqs.us-east-2.amazonaws.com/146677488329/CpifQueue";
            string SqsQueueUrl = ConfigurationManager.AppSettings[AmazonSQSQueueUrl];

            var messageRequest = new SendMessageRequest
            {
                DelaySeconds = (int)TimeSpan.FromSeconds(5).TotalSeconds,
                MessageAttributes = new Dictionary<string, MessageAttributeValue>
                  {
                    {
                      "FileName", new MessageAttributeValue
                        { DataType = "String", StringValue = fileName }
                    },
                    {
                      "DataLocation", new MessageAttributeValue
                        { DataType = "String", StringValue = dataStreamLocation }
                    },
                    {
                      "SessionId", new MessageAttributeValue
                        { DataType = "String", StringValue = sessionId }
                    },
                    {
                      "MessageId", new MessageAttributeValue
                        { DataType = "String", StringValue = messageId }
                    }
                  },
                MessageBody = cloudMessage,
                QueueUrl = SqsQueueUrl
            };

            sqsClient.SendMessage(messageRequest);

        }

        #endregion
    }
}
