﻿using Amazon.S3;
using Amazon.S3.Transfer;
using Cpif.Cloud.Common.Utility;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cpif.Cloud.Sender.Amazon.Plugin
{
    public class AmazonCloudS3BucketSenderEngine
    {
        #region Config Keys

        private const string AmazonS3BucketName = "Amazon.S3Bucket.Name";

        #endregion

        #region Public Methods

        /// <summary>
        /// Sends to bucket.
        /// </summary>
        /// <param name="cdtfStreamData">The CDTF stream data.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool SendToBucket(FileStream cdtfStreamData, string fileName)
        {
            string bucketName = ConfigurationManager.AppSettings[AmazonS3BucketName];

            IAmazonS3 s3Client;
            using (s3Client = new AmazonS3Client())
            {
                try
                {
                    var fileTransferUtility = new TransferUtility(s3Client);

                    // Option 2. Specify object key name explicitly.
                    fileTransferUtility.Upload(cdtfStreamData, bucketName, fileName);
                }
                catch (Exception ex)
                {
                    LogDataFacade.LogErrors(ex.Message);
                    return false;
                }
            }
            return true;
        }

        #endregion
    }
}
