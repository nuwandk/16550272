﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Transffering_Application
{
    public class PackageInfo
    {
        public string FilePath { get; set; }
        public string FileName { get; set; }
    }
}
