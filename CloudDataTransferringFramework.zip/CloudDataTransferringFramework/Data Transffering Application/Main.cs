﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_Transffering_Application
{
    public partial class Main : Form
    {
        List<PackageInfo> packagesList;
        string destinationPath;
        const string DASH = "-";
        const string UNDERSCORE = "_";
        string pcName;

        public Main()
        {
            InitializeComponent();
            destinationPath = ConfigurationManager.AppSettings["Folder"].ToString();
            pcName = System.Environment.MachineName;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog.InitialDirectory = @"C:\";
            openFileDialog.Title = "Browse Packages";
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;
            openFileDialog.Multiselect = true;
            packagesList = new List<PackageInfo>();

            string fileName = string.Empty;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                foreach (String path in openFileDialog.FileNames)
                {
                    PackageInfo packageInfo = new PackageInfo();
                    packageInfo.FilePath = path;
                    FileInfo fileInfo = new FileInfo(path);
                    packageInfo.FileName = fileInfo.Name;
                    packagesList.Add(packageInfo);
                    txtPacakges.AppendText(string.Concat(fileInfo.Name, Environment.NewLine));
                }          
            }
        }

        private void btnTransfer_Click(object sender, EventArgs e)
        {
            List<string> clientIdList = new List<string>();     
            string country = string.Empty;

            country = cmbCountry.Text;

            if (txtClientId.Text.Contains("-"))
            {
                var rangeArray = txtClientId.Text.Trim().Split('-');
                int startId = Convert.ToInt32(rangeArray[0].ToString());
                int endId = Convert.ToInt32(rangeArray[1].ToString());

                if (startId >= endId)
                {
                    MessageBox.Show("Please provide a valied client ID Range", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                for (int i  = startId; i  <= endId; i ++)
                {
                    clientIdList.Add(i.ToString());
                }
            }
            else
            {
                if (String.IsNullOrEmpty(txtClientId.Text.Trim()))
                {
                    clientIdList = null;
                }
                else
                {
                    clientIdList = txtClientId.Text.Split(',').ToList();
                }
            }

            if (ValidateInputs(clientIdList, packagesList, country))
            {
                foreach (var package in packagesList)
                {
                    foreach (var id in clientIdList)
	                {
                        string newFileName = string.Concat(country, UNDERSCORE, "CL", DASH, id, UNDERSCORE, pcName, UNDERSCORE, package.FileName);


                        if (!System.IO.Directory.Exists(destinationPath))
                        {
                            System.IO.Directory.CreateDirectory(destinationPath);
                        }

                        string newPath = Path.Combine(destinationPath, newFileName);
                        File.Copy(package.FilePath, newPath, true);
	                } 
                }

                MessageBox.Show("Successfully handover to the server", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
            }
        }


        /// <summary>
        /// Clear the form
        /// </summary>
        private void Clear()
        {
            txtClientId.Clear();
            txtPacakges.Clear();
            cmbCountry.Text = string.Empty;
        }

        private static bool ValidateInputs(List<string> clientIdList, List<PackageInfo> fileNameList, string country)
        {
            bool isValidInputs = true;

            if (string.IsNullOrEmpty(country))
            {
                MessageBox.Show("Please select the country", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                isValidInputs = false;
            }

            if (clientIdList == null || clientIdList.Count() == 0)
            {
                MessageBox.Show("Please provide the client ID's", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                isValidInputs = false;
            }

            if (fileNameList == null || fileNameList.Count() == 0)
            {
                MessageBox.Show("Please provide the data Packages", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                isValidInputs = false;
            }

            return isValidInputs;
        }    
    }
}
