﻿using Cpif.Cloud.Common;
using Cpif.Cloud.Common.Logger;
using Cpif.Framework.Mef;
using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Application
{
    public class Program
    {
        [Import(typeof(ICore))]
        public ICore core;

        private CompositionContainer _compositionContainer;

        private Program()
        {
            var agregateCatalog = new AggregateCatalog();
            agregateCatalog.Catalogs.Add(new AssemblyCatalog(typeof(Program).Assembly));
            agregateCatalog.Catalogs.Add(new DirectoryCatalog("Plugins"));

            _compositionContainer = new CompositionContainer(agregateCatalog);

            try
            {
                this._compositionContainer.ComposeParts(this);
            }
            catch (CompositionException compositionException)
            {
                Console.WriteLine(compositionException.ToString());
            }
        }

        static void Main(string[] args)
        {
            DOMConfigurator.Configure();

            LogWrapper.LogInfo("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

            LogWrapper.LogInfo("CPIF Cloud Sender App Started......");
            Console.Title = "Cpif.Cloud.Sender.App";

            string ActiveVendor = ConfigurationManager.AppSettings["ActiveCloudVendor"].ToString();

            Program program = new Program();

            if (ActiveVendor.ToUpper() == "AMAZON")
            {
                string returnedMessage = program.core.PerformOperations(true, "AmazonCloudSendProcessor");
            }
            if (ActiveVendor.ToUpper() == "AZURE")
            {
                string returnedMessage = program.core.PerformOperations(true, "AzureCloudSendProcessor");
            }

        }
    }
}
